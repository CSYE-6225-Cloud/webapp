#!/bin/bash

sudo dnf update -y