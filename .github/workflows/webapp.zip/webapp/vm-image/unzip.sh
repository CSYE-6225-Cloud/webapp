#!/bin/bash

sudo dnf install -y unzip

mkdir -p /home/Cloud

sudo unzip /tmp/webapp.zip -d /home/Cloud/




